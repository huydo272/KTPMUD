<div class="mt-5 d-flex justify-content-center">
    <form action="logout.php" class="d-flex align-items-center">
        <button type="submit" class="btn btn-danger">Logout</button>
    </form>
</div>
