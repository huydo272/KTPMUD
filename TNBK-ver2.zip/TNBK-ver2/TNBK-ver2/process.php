<?php include 'database.php'; include "checking_login.php";?>
<?php session_start(); ?>
<?php

//Check to see if score is set_error_handler
if (!isset($_SESSION['score'])) {
    $_SESSION['score'] = 0;
}

//Check if form was submitted
//if ($_POST) {
//    $number = $_POST['number'];
//    $selected_choice = $_POST['choice'];
//    $next = $number + 1;
//    $total = 4;
//
//    //Get total number of questions
//    $query = "SELECT * FROM `questions`";
//    $results = $mysqli->query($query) or die($mysqli->error . __LINE__);
//    $total = $results->num_rows;
//
//    //Get correct choice
//    $q = "select * from `choices` where question_number = $number and is_correct=1";
//    $result = $mysqli->query($q) or die($mysqli->error . __LINE__);
//    $row = $result->fetch_assoc();
//    $correct_choice = $row['id'];
//
//
//    //compare answer with result
//    if ($correct_choice == $selected_choice) {
//        $_SESSION['score']++;
//    }
//
//    if ($number == $total) {
//        header("Location: final.php");
//        exit();
//    } else {
//        header("Location: question.php?n=" . $next . "&score=" . $_SESSION['score']);
//    }

$query = "select * from questions";
//Get Results
$results = $mysqli->query($query) or die ($mysqli->error . __LINE__);
$total = $results->num_rows;

// Get Choices
$query = "select * from `choices`";
$resultChoices = $mysqli->query($query) or die($mysqli->error . __LINE__);
$choices = [];

while ($r = $resultChoices->fetch_assoc()) {
    array_push($choices, [
        'id' => $r['id'],
        'question_id' => $r['question_id'],
        'is_correct' => $r['is_correct'],
        'text' => $r['text'],
    ]);
}
$correctQuestion = [];
if ($_POST) {
    foreach ($_POST as $questionId => $value) {
        $results = array_filter($choices, function ($var) use ($questionId) {
            return $var['is_correct'] && $var['question_id'] == $questionId;
        });

        $resultIds = [];
        foreach ($results as $result) {
            array_push($resultIds, $result['id']);
        }

        if (is_array($value)) {
            if (count($value) != count($resultIds)) {
                continue;
            }
            $isCorrect = true;
            foreach ($results as $item) {
                if (!in_array($item['id'], $value)) {
                    $isCorrect = false;
                    break;
                }
            }
            if ($isCorrect) {
                $correctQuestion[] = $questionId;
            }

        } else {
            if (in_array($value, $resultIds)) {
                $correctQuestion[] = $questionId;
            }
        }
    }

    // get current login user
    $query = "SELECT * FROM users where email='{$_SESSION['email']}'";
    $resultUser = $mysqli->query($query) or die ($mysqli->error . __LINE__);
    $userId = (int)$resultUser->fetch_assoc()['id'];

    //
    $query = "SELECT * FROM subjects where id={$_SESSION['subject_id']}";
    $resultSubject = $mysqli->query($query) or die ($mysqli->error . __LINE__);
    $subjectName = $resultSubject->fetch_assoc()['text'];

    $correctAnswerNum = count($correctQuestion);
    $score = (string)$correctAnswerNum . '/15';
    $query = "INSERT INTO scores (`user_id`, `subject_name`, `score`, `time`) value ({$userId}, '{$subjectName}', '{$score}', now())";
    $mysqli->query($query) or die ($mysqli->error . __LINE__);

    // list scores
    $query = "SELECT * FROM scores where user_id={$userId}";
    $resultListScores = $mysqli->query($query) or die ($mysqli->error . __LINE__);
    $listScores  = [];
    while ($r = $resultListScores->fetch_assoc()) {
        array_push($listScores, [
            'id' => $r['id'],
            'subject_name' => $r['subject_name'],
            'score' => $r['score'],
            'time' => $r['time'],
        ]);
    }

}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Kết quả</title>
    <link rel="stylesheet" href="css/style.css" type="text/css"/>
    <link rel="stylesheet" href="css/bootstrap.css">
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/jquery.min.js"></script>
    <script src="/js/popper.min.js"></script>
    <script src="../js/js_table.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container">
        <h3><center>Kết quả</h3>

        <div class="card">
            <div class="card-body">
                <p id="result">Số câu trả lời đúng: <?php echo count($correctQuestion); ?>/<?php
                    if ($total < 15)
                    echo $total;
                    else {
                        echo 15;
                    }
                ?> </p>


                <?php $progress = round(count($correctQuestion)/($total < 15 ? $total : 15)*100, 2); ?>
                <div class="progress mb-2">
                    <div class="progress-bar" role="progressbar" style="width: <?php echo $progress;?>%;" aria-valuenow="<?php echo $progress;?>" aria-valuemin="0" aria-valuemax="100"><?php echo $progress;?>%</div>
                </div>
                <a type="button" class="btn btn-success" href="/">Try again!</a>
                <div class="table-wrapper">
                    <div class="table-title">
                        <div class="row">
                            <div class="col-sm-6">
                                <h2>Lịch sử</h2>
                            </div>
                        </div>
                    </div>
                    <table class="table table-striped table-hover">
                        <thead>
                        <tr>
                            <th>Môn học</th>
                            <th>Điểm số</th>
                            <th>Thời gian hoàn thành</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        foreach ($listScores as $score) {
                            echo "
                        <tr>
                            <td>{$score['subject_name']}</td>
                            <td>{$score['score']}</td>
                            <td>{$score['time']}</td>    
                        </tr>
                        ";
                        }
                        ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php include 'logout_html.php'; ?>
</body>
</html>
