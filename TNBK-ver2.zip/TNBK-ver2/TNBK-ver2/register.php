<?php include "database.php";
    session_start();
    $message = '';

    // validate email with domain @sis.hust.edu.vn (16 characters)
    if (filter_var($_POST["email"], FILTER_VALIDATE_EMAIL) && ((strlen($_POST["email"]) - strpos($_POST["email"], '@sis.hust.edu.vn') != 16))) {
        $_SESSION['message'] = 'Invalid email, email must include @sis.hust.edu.vn!';
        header("Location:register_html.php");
        exit;
    }

    $query = "INSERT INTO users (`email`, `password`) values ('{$_POST['email']}', '{$_POST['password']}')";
    $results = $mysqli->query($query)  or die ($mysqli->error . __LINE__);

    $_SESSION['success'] = 'Register successfully!';
    header("Location:login_html.php");
