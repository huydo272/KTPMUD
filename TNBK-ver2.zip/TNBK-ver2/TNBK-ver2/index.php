<?php
session_start();
include "database.php";
include "checking_login.php";
?>

<?php
//Get the total questions
$query = "select * from questions";
//Get Results
// Get subjects
$query = "select * from subjects";
$resultSubjects = $mysqli->query($query) or die($mysqli->error . __LINE__);
$subjects  = [];

while ($r = $resultSubjects->fetch_assoc()) {
    array_push($subjects, [
        'id' => $r['id'],
        'text' => $r['text'],
    ]);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Ôn thi HUST</title>
    <link rel="stylesheet" href="css/style.css" type="text/css"/>
    <link rel="stylesheet" href="css/bootstrap.css">
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/jquery.min.js"></script>
    <script src="/js/popper.min.js"></script>
</head>
<body>
<div id="container">
    <div class="container">
        <div class="jumbotron">
            <h3><center>IN HUST WE TRUST<center></h3>
            <p>Hạnh phúc là khi con người ta biết thế nào là đủ. Bạn muốn A+ hay là D, tất cả phụ thuộc ở chính bản thân bạn.</p>
            <p>Let's begin<p>
            <form action="question.php">
                <select name="subject_id" class="form-control form-select form-select-lg mb-3" aria-label=".form-select-lg example">
                    <?php
                        foreach ($subjects as $subject) {
                            echo "<option value='{$subject['id']}'>{$subject['text']}</option>";
                        }
                    ?>
                </select> <br>
                <button type="submit" class="btn btn-info">Bắt đầu</button>
            </form>
        </div>
    </div>
    <?php include 'logout_html.php'; ?>
</body>
</html>