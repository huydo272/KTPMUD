<?php
session_start();
include "../database.php";

$query = "INSERT INTO subjects (`text`) value ('{$_POST['text']}')";
$resultSubjects = $mysqli->query($query) or die($mysqli->error . __LINE__);
$_SESSION['successfully'] = true;
header('Location: ' . $_SERVER['HTTP_REFERER']);