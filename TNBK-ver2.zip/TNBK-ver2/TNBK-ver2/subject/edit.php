<?php
session_start();
include "../database.php";

$query = "UPDATE subjects SET text = '{$_POST['text']}' WHERE id = {$_POST['id']}";
$resultUsers = $mysqli->query($query) or die($mysqli->error . __LINE__);
$_SESSION['successfully'] = true;
header('Location: ' . $_SERVER['HTTP_REFERER']);