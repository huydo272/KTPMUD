<?php
session_start();
include "../database.php";
$query = "DELETE FROM subjects WHERE id = {$_GET['id']}";
$resultUsers = $mysqli->query($query) or die($mysqli->error . __LINE__);
$_SESSION['successfully'] = true;
header('Location: ' . $_SERVER['HTTP_REFERER']);
