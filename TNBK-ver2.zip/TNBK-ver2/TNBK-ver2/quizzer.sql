drop database if exists quizzer;
create database quizzer;
use  quizzer;

CREATE TABLE questions
(
    `id`              int NOT NULL AUTO_INCREMENT,
    `subject_id`      int NOT NULL,
    `is_multi_choice` boolean DEFAULT false,
    `text`            text,
    primary key (`id`)
);

CREATE TABLE choices
(
    `id`              int NOT NULL AUTO_INCREMENT,
    `question_id`     int NOT NULL,
    `is_correct`      boolean DEFAULT false,
    `text`            text,
    PRIMARY KEY (`id`, `question_id`)
);

CREATE TABLE subjects
(
    `id`   int NOT NULL AUTO_INCREMENT,
    `text` text,
    PRIMARY KEY (`id`)
);

CREATE TABLE users
(
    `id`              int NOT NULL AUTO_INCREMENT,
    `email`        text NOT NULL,
    `password`        text NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE TABLE scores
(
    `id`              int NOT NULL AUTO_INCREMENT,
    `user_id`         int NOT NULL,
    `subject_name`    text,
    `score`           text,
    `time`            datetime,
    PRIMARY KEY (`id`)
);

CREATE TABLE admins
(
    `id`              int NOT NULL AUTO_INCREMENT,
    `email`        text NOT NULL,
    `password`        text NOT NULL,
    PRIMARY KEY (`id`)
);

INSERT INTO subjects (`text`) values
('Mathematics'), ('Physics'), ('Chemistry');

INSERT INTO questions (`subject_id`, `is_multi_choice`, `text`) values
(1, true, 'Một cộng 1 bằng: '),
(1, false, '6/2 = '),
(1, true, '8/2 = '),
(1, false, '6/3 = ');

INSERT INTO choices (`question_id`, `is_correct`, `text`) values
(1, true, 'Hai'),
(1, true, '2'),
(1, true, '6/3'),
(1, true, '4/2'),
(2, true, '3'),
(2, false, '4'),
(2, false, '5'),
(2, false, '6'),
(3, true, '4'),
(3, false, '5'),
(4, true, '2'),
(4, false, '3'),
(4, false, '4');

INSERT INTO users (`email`, `password`) value ('user@sis.hust.edu.vn', '1');
INSERT INTO users (`email`, `password`) value ('user2@sis.hust.edu.vn', '1');
INSERT INTO users (`email`, `password`) value ('user3@sis.hust.edu.vn', '1');
INSERT INTO users (`email`, `password`) value ('user4@sis.hust.edu.vn', '1');
INSERT INTO users (`email`, `password`) value ('user5@sis.hust.edu.vn', '1');

INSERT INTO admins (`email`, `password`) value ('admin@sis.hust.edu.vn', '1');
