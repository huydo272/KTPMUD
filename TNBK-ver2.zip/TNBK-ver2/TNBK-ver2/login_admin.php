<?php include "database.php";
    session_start();
    $message = '';
    $query = "SELECT * FROM admins WHERE email='{$_POST["email"]}' and password = '{$_POST["password"]}'";
    $results = $mysqli->query($query);
    $row = $results->fetch_assoc();

    // validate email with domain @sis.hust.edu.vn (16 characters)
    if (filter_var($_POST["email"], FILTER_VALIDATE_EMAIL) && ((strlen($_POST["email"]) - strpos($_POST["email"], '@sis.hust.edu.vn') != 16))) {
        $_SESSION['message'] = 'Invalid email, email must include @sis.hust.edu.vn!';
        header("Location:login_admin_html.php");
        exit;
    }

    if(is_array($row)) {
        $_SESSION["email_admin"] = $row['email'];
        $_SESSION["password"] = $row['password'];
        header("Location:index_admin.php");
    } else {
        $message = "Invalid email or Password!";
        $_SESSION['message'] = $message;
        header("Location:login_admin_html.php");
    }
