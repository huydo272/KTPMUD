<?php
session_start();
include "../database.php";
include "../checking_admin_login.php";

$query = "select * from subjects";
$resultSubjects = $mysqli->query($query) or die($mysqli->error . __LINE__);
$subjects  = [];

while ($r = $resultSubjects->fetch_assoc()) {
    array_push($subjects, [
        'id' => $r['id'],
        'text' => $r['text'],
    ]);
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <title>Subject management</title>
    <link rel="stylesheet" href="../css/style.css" type="text/css"/>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/css_table.css">
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/popper.min.js"></script>
    <script src="../js/js_table.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
        :root {
            --color-one: #e6e6ff;
            --color-two: #1a1aff;
            --color-three: #b3b3ff;
        }

        .container {
            margin: 0;
            position: absolute;
            top: 55%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .card {
            border: 1px solid var(--color-three);
            margin-bottom: 20px;
            transition: border 0.1s, transform 0.3s;
        }

        .card:hover {
            border: 1px solid var(--color-two);
            -webkit-transform: translateY(-10px);
            transform: translateY(-10px);
            cursor: pointer;
        }

        .card .card-body h2 {
            color: var(--color-two);
        }

        .card img:hover {
            opacity: 0.6;
        }

        .card-p {
            color: var(--color-three);
        }

        .card-p i {
            color: var(--color-two);
            margin-right: 8px;
        }
    </style>
</head>
<body>

<div class="container">
    <br>
    <br>
    <h1><center>Chọn môn học</center></h1>
    <br>
    <br>
    <div class="row">

        <?php
            foreach ($subjects as $subject) {
                echo "
                            <div class='col-xs-12 col-sm-12 col-md-4 col-lg-4' onclick='redirectQuestion({$subject['id']}, \"{$subject['text']}\")'>
                                <div class='card shadow'>
                                    <img src='../images/image-20200829-1138.png' class='card-img-top' alt='...'>
                                    <div class='card-body'>
                                        <h2 class='card-title' style='text-align: center'>{$subject['text']}</h2>
                                    </div>
                                    <div class='card-body card-p'>
                                        <div class='row'>
                    
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            ";
            }
        ?>
    </div>
    <script>
        function redirectQuestion(id, name) {
            console.log(id)
            location.href = `list.php?subject_id=${id}&subject_name=${name}`;
        }
    </script>
</div>
</body>
</html>
