<?php
session_start();
include "../database.php";
include "../checking_admin_login.php";

$query = "select * from questions where subject_id = {$_GET['subject_id']}";
$resultQuestions = $mysqli->query($query) or die($mysqli->error . __LINE__);
$questions = [];

while ($r = $resultQuestions->fetch_assoc()) {
    array_push($questions, [
        'id' => $r['id'],
        'text' => $r['text'],
        'is_multi_choice' => $r['is_multi_choice'],
    ]);
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Subject management</title>
    <link rel="stylesheet" href="../css/style.css" type="text/css"/>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/css_table.css">
    <script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/popper.min.js"></script>
    <script src="../js/js_table.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<?php
include "../alert.php";
?>
<div id="container">
    <div class="table-wrapper">
        <div class="table-title">
            <div class="row">
                <div class="col-sm-6">
                    <h2>List <b><?php echo $_GET['subject_name']; ?></b> questions</h2>
                </div>
                <div class="col-sm-6">
                    <a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xE147;</i>
                        <span>Add New Subject</span></a>
                    <!--                        <a href="#deleteEmployeeModal" class="btn btn-danger" data-toggle="modal"><i class="material-icons">&#xE15C;</i> <span>Delete</span></a>-->
                </div>
            </div>
        </div>
        <table class="table table-striped table-hover">
            <thead>
            <tr>
                <th>Id</th>
                <th>Title</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach ($questions as $question) {
                echo "
                        <tr>
                            <td>{$question['id']}</td>
                            <td>{$question['text']}</td>
                            <td>
                                <a href='#editEmployeeModal' class='edit' data-toggle='modal'><i class='material-icons' data-toggle='tooltip' title='Edit'  onclick='handleQuestionEdit(\"{$question['id']}\", \"{$question['text']}\", \"{$question['is_multi_choice']}\")'>&#xE254;</i></a>
                                <a class='delete' href='delete.php?id={$question['id']}'><i class='material-icons' data-toggle='tooltip' title='Delete'>&#xE872;</i></a>                                
                            </td>
                        </tr>
                        ";
            }
            ?>

            </tbody>
        </table>
    </div>
    <!-- Edit Modal HTML -->
    <div id="addEmployeeModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="create.php" method="post">
                    <input type="text" name="subject_id" value="<?php echo $_GET['subject_id']; ?>" hidden>
                    <div class="modal-header">
                        <h4 class="modal-title">Add Questions</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Question</label>
                            <textarea class="form-control" rows="3" name="text" style="width: 100%" required></textarea>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Type</label>
                            <select name="type" class="form-control" onchange="handleType()" id="type">
                                <option value="0" selected>Only one answer</option>
                                <option value="1">Multiple choice</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Answer</label>
                            <div class="row  d-flex  justify-content-center">
                                <div class="col-lg-12" id="answerField">
                                    <div class="input-group mt-3">
                                        <span class="input-group-addon">
                                            <input type="radio" aria-label="..." name="isCorrect[]" value="0">
                                        </span>
                                        <textarea class="form-control" name="answer[]" rows="3" style="width: 100% !important;" required></textarea>
                                    </div>
                                </div>
                                <a  class="btn btn-success mt-5" style="padding: 0; margin: 0; width: auto" onclick="addNewAnswer()"><i class="material-icons" style="color: white">&#xE147;</i></a>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                        <input type="submit" class="btn btn-success" value="Add">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Edit Modal HTML -->
    <div id="editEmployeeModal" class="modal fade">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form action="edit.php" method="post">
                    <input type="text" name="id" id="question_id" hidden>
                    <div class="modal-header">
                        <h4 class="modal-title">Edit Subject</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Question</label>
                            <textarea class="form-control" rows="3" name="text" style="width: 100%" required id="textEdit"></textarea>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Type</label>
                            <select name="type" class="form-control" onchange="handleTypeEdit()" id="editType">
                                <option value="0" selected>Only one answer</option>
                                <option value="1">Multiple choice</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Answer</label>
                            <div class="row  d-flex  justify-content-center">
                                <div class="col-lg-12" id="editAnswerField">
                                    <div class="input-group mt-3">
                                        <span class="input-group-addon">
                                            <input type="radio" aria-label="..." name="isCorrect[]" value="0">
                                        </span>
                                        <textarea class="form-control" name="answer[]" rows="3" style="width: 100% !important;" required></textarea>
                                    </div>
                                </div>
                                <a  class="btn btn-success mt-5" style="padding: 0; margin: 0; width: auto" onclick="addNewAnswerEdit()"><i class="material-icons" style="color: white">&#xE147;</i></a>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                        <input type="submit" class="btn btn-info" value="Save">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Delete Modal HTML -->
    <div id="deleteEmployeeModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <form>
                    <div class="modal-header">
                        <h4 class="modal-title">Delete Employee</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>Are you sure you want to delete these Records?</p>
                        <p class="text-warning"><small>This action cannot be undone.</small></p>
                    </div>
                    <div class="modal-footer">
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                        <input type="submit" class="btn btn-danger" value="Delete">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function renderViaType(type, value = 0) {
            return `
                    <div class="input-group mt-3">
                        <span class="input-group-addon">
                            <input type="${type == 0 ? 'radio' : 'checkbox'}" aria-label="..." name="isCorrect[]" value="${value}">
                        </span>
                        <textarea class="form-control" name="answer[]" rows="3" style="width: 100% !important;" required></textarea>
                    </div>
                `;
        }
        function handleType() {
            let root = $('#answerField');
            let ele = renderViaType(parseInt(document.getElementById('type').value))
            root.empty()
            root.append(ele)
        }
        function addNewAnswer() {
            let root = $('#answerField');
            let ele = renderViaType(parseInt(document.getElementById('type').value), root.children().length)
            root.append(ele);
        }

        function addNewAnswerEdit() {
            let root = $('#editAnswerField');
            let ele = renderViaType(parseInt(document.getElementById('editType').value), root.children().length)
            root.append(ele);
        }

        function handleTypeEdit() {
            let root = $('#editAnswerField');
            let ele = renderViaType(parseInt(document.getElementById('editType').value))
            root.empty()
            root.append(ele)
        }

        function handleQuestionEdit(id, text, isMulti) {
            let elEdit = $('#editAnswerField');
            $.ajax({
                url: "AjaxGetChoice.php",
                type: "get",
                data: {
                    question_id: parseInt(id),
                },
                success: function(response) {
                    console.log(response)
                    elEdit.empty();
                    $('#question_id').val(id)
                    $('#textEdit').val(text);
                    $('#editType').val(isMulti);
                    response.forEach(function (currentValue, index, arr) {
                        elEdit.append(renderChoice(isMulti, currentValue, index));
                    })
                },
                error: function(xhr) {

                }
            });

        }

        function renderChoice(type, choice, index) {
            let isCorrect = Boolean(parseInt(choice.is_correct));
            return `
                    <div class="input-group mt-3">
                        <span class="input-group-addon">
                            <input type="${type == 0 ? 'radio' : 'checkbox'}" aria-label="..." name="isCorrect[]" value="${index}" ${ isCorrect ? 'checked' : ''}>
                        </span>
                        <textarea class="form-control" name="answer[]" rows="3" style="width: 100% !important;" required>${choice.text}</textarea>
                    </div>
                `;
        }
    </script>

    <?php include 'logout_html.php'; ?>
</body>
</html>
