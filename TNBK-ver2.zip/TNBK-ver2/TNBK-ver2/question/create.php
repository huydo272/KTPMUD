<?php
session_start();
include "../database.php";
include "../checking_admin_login.php";

// get data
$questionTitle = $_POST['text'];
$questionType = $_POST['type'];
$subjectId = $_POST['subject_id'];
$query = "INSERT INTO questions (`subject_id`, `is_multi_choice`, `text`) value ({$subjectId}, {$questionType}, '{$questionTitle}')";
$resultQuestions = $mysqli->query($query) or die($mysqli->error . __LINE__);

$correctAnswer = array_values($_POST['isCorrect']);
$correctAnswer = array_map(function ($item){ return (int)$item; }, $correctAnswer);

$arrayParam = [];
$strParam = "";
foreach ($_POST['answer'] as $key => $value) {
    $check = (int)in_array($key, $correctAnswer);
    $strParam = "(";
    $strParam .= "{$mysqli->insert_id}, {$check}, '{$value}'";
    $strParam .= ")";
    array_push($arrayParam, $strParam);
}

$arrayParam = implode(',', $arrayParam);

$query = "INSERT INTO choices (`question_id`, `is_correct`, `text`) values {$arrayParam}";
$mysqli->query($query) or die($mysqli->error . __LINE__);
$_SESSION['successfully'] = true;
header('Location: ' . $_SERVER['HTTP_REFERER']);