<?php
session_start();
include "../database.php";

// update question
$query = "UPDATE questions SET text = '{$_POST['text']}', is_multi_choice = {$_POST['type']} WHERE id = {$_POST['id']}";
$resultUsers = $mysqli->query($query) or die($mysqli->error . __LINE__);

$query = "DELETE FROM choices WHERE question_id = {$_POST['id']}";
$mysqli->query($query) or die($mysqli->error . __LINE__);
// create choices
$correctAnswer = array_values($_POST['isCorrect']);
$correctAnswer = array_map(function ($item){ return (int)$item; }, $correctAnswer);

$arrayParam = [];
$strParam = "";
foreach ($_POST['answer'] as $key => $value) {
    $check = (int)in_array($key, $correctAnswer);
    $strParam = "(";
    $strParam .= "{$_POST['id']}, {$check}, '{$value}'";
    $strParam .= ")";
    array_push($arrayParam, $strParam);
}

$arrayParam = implode(',', $arrayParam);

$query = "INSERT INTO choices (`question_id`, `is_correct`, `text`) values {$arrayParam}";
$mysqli->query($query) or die($mysqli->error . __LINE__);
$_SESSION['successfully'] = true;
header('Location: ' . $_SERVER['HTTP_REFERER']);