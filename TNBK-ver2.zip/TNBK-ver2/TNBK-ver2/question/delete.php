<?php
session_start();
include "../database.php";
$query = "DELETE FROM questions WHERE id = {$_GET['id']}";
$resultUsers = $mysqli->query($query) or die($mysqli->error . __LINE__);
$_SESSION['successfully'] = true;
header('Location: ' . $_SERVER['HTTP_REFERER']);
