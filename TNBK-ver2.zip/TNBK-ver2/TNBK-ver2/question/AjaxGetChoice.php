<?php
session_start();
include "../database.php";

$query = "select * from choices where question_id = " . $_GET['question_id'];

$resultChoices = $mysqli->query($query) or die($mysqli->error . __LINE__);

$choice  = [];

while ($r = $resultChoices->fetch_assoc()) {
    array_push($choice, [
        'id' => $r['id'],
        'text' => $r['text'],
        'is_correct' => $r['is_correct'],
        'question_id' => $r['question_id'],
    ]);
}

header('Content-type: application/json');
echo json_encode($choice);