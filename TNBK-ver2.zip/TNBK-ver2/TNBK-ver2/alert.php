<?php
session_start();

if ($_SESSION['successfully']) {
    echo "
    <div class='alert alert-success text-center' role='alert'>
        <strong>Successfully!</strong>
    </div>
    ";
    unset ($_SESSION["successfully"]);
}