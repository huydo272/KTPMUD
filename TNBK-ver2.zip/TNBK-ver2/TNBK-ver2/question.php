<?php include "database.php"; include "checking_login.php"; ?>
<?php session_start(); ?>
<?php
//Set question number
$number = (int)$_GET['n'];

////Get total number of questions
//$query = "select * from questions";
//$results = $mysqli->query($query) or die($mysqli->error . __LINE__);
//$total = $results->num_rows;

// Get Questions
$query = "select * from `questions` where subject_id = {$_GET['subject_id']} ORDER BY RAND() LIMIT 15";
$resultQuestions = $mysqli->query($query) or die($mysqli->error . __LINE__);

// set subject_id
$_SESSION['subject_id'] = (int)$_GET['subject_id'];


// Get Choices
$query = "select * from `choices`";
$resultChoices = $mysqli->query($query) or die($mysqli->error . __LINE__);
$choices = [];

while ($r = $resultChoices->fetch_assoc()) {
    array_push($choices, [
        'id' => $r['id'],
        'question_id' => $r['question_id'],
        'text' => $r['text'],
    ]);
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Ôn thi HUST</title>
    <link rel="stylesheet" href="css/style.css" type="text/css"/>
    <link rel="stylesheet" href="css/bootstrap.css">
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/jquery.min.js"></script>
    <script src="/js/popper.min.js"></script>
</head>
<body>
<div class="container">
    <!--    <div class="container">-->
    <!--        <div class="current">Question --><?php //echo $number; ?><!-- of --><?php //echo $total; ?><!--</div>-->
    <!--        <p class="question">-->
    <!--            --><?php //echo $question['question'] ?>
    <!--        </p>-->
    <!--        <form method="post" action="process.php">-->
    <!--            <ul class="choices">-->
    <!--                --><?php //while ($row = $choices->fetch_assoc()): ?>
    <!--                    <li><input name="choice" type="radio" value="--><?php //echo $row['id']; ?><!--"/>-->
    <!--                        --><?php //echo $row['choice']; ?>
    <!--                    </li>-->
    <!--                --><?php //endwhile; ?>
    <!--            </ul>-->
    <!--            <input type="submit" value="submit"/>-->
    <!--            <input type="hidden" name="number" value="--><?php //echo $number; ?><!--"/>-->
    <!--        </form>-->
    <!--    </div>-->
    <form action="process.php" method="post">
        <?php
        $i = 0;
        while ($row = $resultQuestions->fetch_assoc()) {
            $filterChoices = array_filter($choices, function ($choice) use ($row) {
                return $choice['question_id'] == $row['id'];
            });
            ?>
            <div class="card border-info mb-4 d-flex ">
                <div class="d-flex justify-content-between align-items-center card-header bg-info text-white" id="h1">
                    <span>Question <?php echo ++$i; ?></span>
                </div>
                <div id="q1" class="collapse show" aria-labelledby="h1">
                    <div class="card-body">
                        <h3><?php echo $row['text']; ?></h3>

                        <?php
                        if ($row['is_multi_choice'] == true) {
                            $asciiCode = 64;
                            foreach ($filterChoices as $key => $value) {

                                ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="<?php echo $row['id']; ?>[]" value="<?php echo $value['id']; ?>" >
                                    <label class="form-check-label">
                                        <?php echo chr(++$asciiCode) .'. ' . $value['text']; ?>
                                    </label>
                                </div>

                                <?php
                            }
                        } else {
                            $asciiCode = 64;
                            foreach ($filterChoices as $key => $value) {

                                ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="<?php echo $row['id']; ?>" value="<?php echo $value['id']; ?>">
                                    <label class="form-check-label" for="q1_r1">
                                        <?php echo chr(++$asciiCode) .'. ' . $value['text']; ?>
                                    </label>
                                </div>

                                <?php
                            }
                            ?>

                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
        <div class="d-flex align-items-center">
            <button type="submit" class="btn btn-success">Submit</button>
        </div>
    </form>
    <?php include 'logout_html.php'; ?>
</div>
</body>
</html>